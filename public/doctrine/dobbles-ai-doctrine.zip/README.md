# Operating Doctrine — Annotated Package

This is the working operating doctrine I use with Claude, every day, across every project. I'm sharing it because a LinkedIn post about the importance of AI governance shouldn't just be theory — if I'm saying it matters, I should show what mine actually looks like.

## What's In This Package

| File | Purpose | Read First? |
|------|---------|-------------|
| `DOCTRINE_ANNOTATED.md` | The Core doctrine with full commentary on every section | **Yes — start here** |
| `BRAND_ANNOTATED.md` | Visual design system module | Only if you do visual work |
| `STACK_ANNOTATED.md` | Tech stack and deployment rules module | Only if you build software |
| `SKILLS_ANNOTATED.md` | Tools, connectors, and chaining workflows module | Yes — high leverage |
| `PROJECT_EXAMPLE.md` | Generic per-project scaffold | When you're ready to apply this to your own work |

## How To Read This

Start with `DOCTRINE_ANNOTATED.md`. It's the Core — about 600 words of actual doctrine, heavily annotated with "why this is here" commentary in blockquotes. The design decisions matter more than the specific rules.

Each annotation explains either (a) what problem the rule solves, (b) what failure mode it prevents, or (c) why the rule has the specific shape it has. The rules themselves are less interesting than the reasoning, because the reasoning transfers to your situation and the rules might not.

After the Core, the module files are reference material. Read the ones that apply to how you work. Skip the ones that don't.

## How To Use This

Don't copy my doctrine. Write your own. The personal specifics — how I want to be talked to, what I'm working on, what I've been burned by — are what make it effective. A genericized version would feel generic.

The things worth copying are the *patterns*:

1. **Precedence rules** — four lines that tell the model what to prioritize when rules conflict
2. **Risk gates** — the split between actions that proceed automatically and actions that require approval
3. **Prompt injection defense** — one paragraph, non-negotiable if you have connectors
4. **Behavioral contract** — your tone, your way of thinking, your "never do this"
5. **Confidence rubric** — three tags that change decision quality
6. **Modularization** — Core plus loadable modules, not one giant file

The rest is my specifics. Yours will be different.

## What's Missing (Deliberately)

A few things I was told to add and deliberately didn't:

- **Verification logs on every deliverable.** Becomes theater within two weeks. Scope it to high-stakes categories only.
- **Multi-file state artifacts** (`todo.md`, `decisions.md`, `lessons.md`). Duplicates what `PROJECT.md` already does. More files to maintain is the same disease as a monolith doctrine.
- **Evaluator-optimizer loop as the default for all work.** Adds latency and token cost to every task. Reserve for high-stakes work.

If any of those would solve a real problem for you, add them. But the default doctrine should be the smallest thing that works. Add complexity when you've earned it.

## One Note On What's Been Redacted

The personal version of this doctrine names specific employers, active clients, and current engagements. Those are removed from the shared copy. The structure is identical; only the specifics are generalized. If you're building your own, include your specifics — they're what makes it effective.

## Credit and License

Use this however is helpful. Adapt it, mangle it, ignore it, improve on it. If you build something better, I want to see it — the whole point of sharing operating patterns is that they compound across the people using them.

— Ed
